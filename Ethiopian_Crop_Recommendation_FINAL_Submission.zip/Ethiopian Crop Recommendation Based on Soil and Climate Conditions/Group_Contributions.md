# Group Member Contributions

## Module 5 contributions

| No. | Member name | Role area | Specific contribution |
|---:|---|---|---|
| 1 | Nigussie Tebeje | Problem definition and requirements | Drafted the problem refinement (top-three crop-label ranking, not yield prediction) and AI solution design (candidate models and Macro-F1 as the selection metric). |
| 2 | Bewketu Dessie | Data preparation | Implemented data validation (numeric conversion, missing and non-finite values, label cleaning) and the stratified 70/15/15 split with `random_state=42`. |
| 3 | Tigst Amare | Exploratory data analysis | Produced class-count, histogram and correlation charts and reviewed feature ranges and class overlap. |
| 4 | Aysheshim Abrham | Model development | Built the majority baseline, Decision Tree, Random Forest and Gradient Boosting candidates and the validation comparison table. |
| 5 | Dana Ayele | Evaluation | Evaluated the selected model on the held-out test set: accuracy, Macro-F1, top-3 accuracy, classification report and confusion matrix. |
| 6 | Belete Shawel | Prototype and testing | Implemented the `recommend_top3` function and Streamlit application, and saved the model and metadata; contributed to web-interface testing. |
| 7 | Mussie Hailemarkos | Testing | Re-ran the notebook from beginning to end and verified that the saved model reproduces the reported test metrics. |
| 8 | Adem Hussien | Documentation | Wrote the executive summary, data preparation and conclusion sections of the report. |
| 9 | Fentaye Abrham | Development and documentation | Wrote the README and the reproducibility and limitations sections. |
| 10 | Asmamaw Moges | To be confirmed | Module 5 contribution was not listed in the supplied Module 5 contribution table. Add the member's actual contribution after confirmation. |
| 11 | Ahadu Gebresenbet | To be confirmed | Module 5 contribution was not listed in the supplied Module 5 contribution table. Add the member's actual contribution after confirmation. |

**Name check:** The supplied Module 5 table spells the sixth member's name "Belete Shawel". Confirm this spelling against the official group roster before submission.

## Module 6 contributions and video speaking roles

The assignment requires every group member to contribute meaningfully and speak in the presentation. The entries below are planning suggestions, not confirmation of work performed. Each member must confirm or correct their own row. Do not submit unconfirmed responsibilities as factual claims.

| No. | Member | Proposed Module 6 presentation area | Proposed video segment | Confirmation |
|---:|---|---|---|---|
| 1 | Nigussie Tebeje | Problem and solution introduction | 0:00–0:50 | Pending |
| 2 | Bewketu Dessie | Dataset and simulated-data statement | 0:50–1:40 | Pending |
| 3 | Tigst Amare | Streamlit prototype demonstration | 1:40–2:30 | Pending |
| 4 | Aysheshim Abrham | Candidate models and MLflow experiment tracking | 2:30–3:20 | Pending |
| 5 | Dana Ayele | Evaluation results | 3:20–4:10 | Pending |
| 6 | Belete Shawel | Model artifacts and deployment approach | 4:10–5:00 | Pending |
| 7 | Mussie Hailemarkos | FastAPI, input validation, API tests and simulated monitoring demo | 5:00–6:15 | Pending |
| 8 | Adem Hussien | Monitoring, support and maintenance plan | 6:15–7:05 | Pending |
| 9 | Fentaye Abrham | Portfolio documentation and written retrospective | 7:05–7:55 | Pending |
| 10 | Asmamaw Moges | Limitations and responsible use (proposed; replace if actual contribution differs) | 7:55–8:40 | Pending |
| 11 | Ahadu Gebresenbet | Future work and closing summary (proposed; replace if actual contribution differs) | 8:40–9:20 | Pending |

The segments total 9 minutes 20 seconds, leaving 40 seconds of margin under the 10-minute limit. Wording for each segment is in `docs/Capstone_Video_Script.docx`.

**Before recording:** Replace every "Pending" entry with a confirmation, correct the proposed roles to match actual work, and ensure each member can explain their contribution and demonstrate understanding of the overall project.
